// Shawarma Hamamas - JavaScript
// Inspired by YouTube video: https://youtu.be/LcDBXC_sfB0

// ========================================
// CONFIGURATION
// ========================================
const CONFIG = {
    whatsappNumber: "56900000000",
    whatsappBaseUrl: "https://wa.me",
    scrollOffset: 100,
    animationDelay: 100
};

// ========================================
// DOM CONTENT LOADED
// ========================================
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// ========================================
// APP INITIALIZATION
// ========================================
function initializeApp() {
    initializeLucideIcons();
    initializeMobileMenu();
    initializeSmoothScroll();
    initializeScrollEffects();
    initializeContactForm();
    initializeAnimations();
    initializeParallax();
    console.log('🍽️ Shawarma Hamamas website initialized');
}

// ========================================
// LUCIDE ICONS
// ========================================
function initializeLucideIcons() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
        console.log('✨ Lucide icons initialized');
    }
}

// ========================================
// MOBILE MENU
// ========================================
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const nav = document.getElementById('nav');
    
    if (mobileMenuBtn && nav) {
        // Toggle mobile menu
        mobileMenuBtn.addEventListener('click', function() {
            nav.classList.toggle('open');
            toggleMobileMenuIcon(mobileMenuBtn);
        });
        
        // Close menu when clicking on nav links
        nav.addEventListener('click', function(e) {
            if (e.target.classList.contains('nav-link')) {
                nav.classList.remove('open');
                resetMobileMenuIcon(mobileMenuBtn);
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!nav.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                nav.classList.remove('open');
                resetMobileMenuIcon(mobileMenuBtn);
            }
        });
        
        // Handle escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && nav.classList.contains('open')) {
                nav.classList.remove('open');
                resetMobileMenuIcon(mobileMenuBtn);
            }
        });
    }
}

function toggleMobileMenuIcon(button) {
    const icon = button.querySelector('i');
    if (icon) {
        icon.setAttribute('data-lucide', nav.classList.contains('open') ? 'x' : 'menu');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

function resetMobileMenuIcon(button) {
    const icon = button.querySelector('i');
    if (icon) {
        icon.setAttribute('data-lucide', 'menu');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

// ========================================
// SMOOTH SCROLL
// ========================================
function initializeSmoothScroll() {
    // Handle navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Skip if it's just "#"
            if (href === '#') {
                e.preventDefault();
                return;
            }
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                scrollToTarget(target, CONFIG.scrollOffset);
            }
        });
    });
}

function scrollToTarget(target, offset) {
    const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
    
    window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
    });
}

// ========================================
// SCROLL EFFECTS
// ========================================
function initializeScrollEffects() {
    let lastScrollTop = 0;
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Header background on scroll
        if (scrollTop > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
        
        // Hide/show header on scroll direction
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // Scrolling down
            header.style.transform = 'translateY(-100%)';
        } else {
            // Scrolling up
            header.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
    });
    
    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.feature-card, .menu-item, .gallery-item, .contact-card').forEach(el => {
        observer.observe(el);
    });
}

// ========================================
// CONTACT FORM
// ========================================
function initializeContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleContactFormSubmission(this);
        });
        
        // Real-time validation
        const inputs = contactForm.querySelectorAll('.form-input, .form-textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
    }
}

function handleContactFormSubmission(form) {
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    
    // Validate form
    if (!validateForm(data)) {
        showNotification('Por favor, completa todos los campos requeridos.', 'error');
        return;
    }
    
    // Show loading state
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i data-lucide="loader-2" class="animate-spin"></i> Enviando...';
    submitBtn.disabled = true;
    
    // Simulate form submission (replace with actual API call)
    setTimeout(() => {
        // Reset form
        form.reset();
        
        // Restore button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Show success message
        showNotification('¡Mensaje enviado! Te contactaremos pronto.', 'success');
        
        // Send to WhatsApp as fallback
        sendToWhatsApp(data);
        
        // Reinitialize icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }, 2000);
}

function validateForm(data) {
    const requiredFields = ['name', 'phone', 'message'];
    return requiredFields.every(field => data[field] && data[field].trim().length > 0);
}

function validateField(field) {
    const value = field.value.trim();
    const isRequired = field.hasAttribute('required');
    
    if (isRequired && !value) {
        showFieldError(field, 'Este campo es requerido.');
        return false;
    }
    
    if (field.type === 'email' && value && !isValidEmail(value)) {
        showFieldError(field, 'Por favor, ingresa un email válido.');
        return false;
    }
    
    if (field.type === 'tel' && value && !isValidPhone(value)) {
        showFieldError(field, 'Por favor, ingresa un teléfono válido.');
        return false;
    }
    
    clearFieldError(field);
    return true;
}

function showFieldError(field, message) {
    clearFieldError(field);
    field.classList.add('error');
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.classList.remove('error');
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[0-9\s\-\(\)]{8,15}$/;
    return phoneRegex.test(phone);
}

function sendToWhatsApp(data) {
    const message = `Hola! Soy ${data.name}\n\n${data.message}\n\nMi teléfono: ${data.phone}${data.email ? `\nEmail: ${data.email}` : ''}`;
    const whatsappUrl = `${CONFIG.whatsappBaseUrl}/${CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// ========================================
// ANIMATIONS
// ========================================
function initializeAnimations() {
    // Typing animation for hero title
    typeWriterEffect();
    
    // Parallax effect for hero background
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallax = document.querySelector('.hero-bg-image');
        if (parallax) {
            const speed = scrolled * 0.5;
            parallax.style.transform = `translateY(${speed}px)`;
        }
    });
}

function typeWriterEffect() {
    const heroTitle = document.querySelector('.hero-title');
    if (!heroTitle) return;
    
    const text = heroTitle.textContent;
    heroTitle.textContent = '';
    heroTitle.style.opacity = '1';
    
    let i = 0;
    const timer = setInterval(() => {
        if (i < text.length) {
            heroTitle.textContent += text.charAt(i);
            i++;
        } else {
            clearInterval(timer);
        }
    }, 100);
}

// ========================================
// PARALLAX EFFECTS
// ========================================
function initializeParallax() {
    // Add parallax class to elements that need it
    const parallaxElements = document.querySelectorAll('[data-parallax]');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset;
        
        parallaxElements.forEach(element => {
            const speed = parseFloat(element.dataset.parallax) || 0.5;
            const yPos = -(scrollTop * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// ========================================
// WHATSAPP INTEGRATION
// ========================================
function initializeWhatsAppButtons() {
    document.querySelectorAll('[href*="wa.me"]').forEach(button => {
        button.addEventListener('click', function(e) {
            // Track WhatsApp clicks
            console.log('📱 WhatsApp button clicked');
        });
    });
}

// Initialize after DOM loaded
document.addEventListener('DOMContentLoaded', initializeWhatsAppButtons);

// ========================================
// UTILITY FUNCTIONS
// ========================================

// Show notification
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i data-lucide="${getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i data-lucide="x"></i>
            </button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        z-index: 10000;
        max-width: 400px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 16px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.3s ease-out;
        font-family: var(--font-body);
    `;
    
    document.body.appendChild(notification);
    
    // Initialize icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'alert-circle',
        warning: 'alert-triangle',
        info: 'info'
    };
    return icons[type] || 'info';
}

function getNotificationColor(type) {
    const colors = {
        success: '#4CAF50',
        error: '#D32F2F',
        warning: '#FFC107',
        info: '#2196F3'
    };
    return colors[type] || '#2196F3';
}

// Debounce function for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for scroll events
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ========================================
// PERFORMANCE OPTIMIZATIONS
// ========================================

// Lazy loading for images
function initializeLazyLoading() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', initializeLazyLoading);

// Preload critical resources
function preloadResources() {
    const criticalImages = [
        'imgs/shawarma-hero.jpg',
        'imgs/logo-shawarma-hamamas.svg'
    ];
    
    criticalImages.forEach(src => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
    });
}

// Initialize preloading
preloadResources();

// ========================================
// ERROR HANDLING
// ========================================
window.addEventListener('error', function(e) {
    console.error('🚨 JavaScript Error:', e.error);
});

// Unhandled promise rejection
window.addEventListener('unhandledrejection', function(e) {
    console.error('🚨 Unhandled Promise Rejection:', e.reason);
});

// ========================================
// ACCESSIBILITY
// ========================================

// Skip to main content
document.addEventListener('keydown', function(e) {
    if (e.key === 'Tab' && !e.shiftKey) {
        const focusableElements = document.querySelectorAll(
            'a[href], button, textarea, input[type="text"], input[type="radio"], input[type="checkbox"], select'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        if (document.activeElement === lastElement && !e.ctrlKey) {
            e.preventDefault();
            firstElement.focus();
        }
    }
});

// Focus management for mobile menu
function manageFocus() {
    const nav = document.getElementById('nav');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    
    if (nav && mobileMenuBtn) {
        nav.addEventListener('transitionend', function() {
            if (nav.classList.contains('open')) {
                const firstLink = nav.querySelector('.nav-link');
                if (firstLink) firstLink.focus();
            } else {
                mobileMenuBtn.focus();
            }
        });
    }
}

// Initialize focus management
document.addEventListener('DOMContentLoaded', manageFocus);

// ========================================
// ANALYTICS & TRACKING
// ========================================

// Track page views
function trackPageView() {
    console.log('📊 Page view tracked:', window.location.pathname);
}

// Track events
function trackEvent(category, action, label) {
    console.log(`📊 Event tracked: ${category} - ${action} - ${label}`);
    
    // Here you would integrate with Google Analytics, Facebook Pixel, etc.
    if (typeof gtag !== 'undefined') {
        gtag('event', action, {
            event_category: category,
            event_label: label
        });
    }
}

// Track scroll depth
function initializeScrollTracking() {
    const milestones = [25, 50, 75, 90];
    const tracked = new Set();
    
    window.addEventListener('scroll', throttle(function() {
        const scrollPercent = Math.round(
            (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
        );
        
        milestones.forEach(milestone => {
            if (scrollPercent >= milestone && !tracked.has(milestone)) {
                tracked.add(milestone);
                trackEvent('Scroll Depth', 'Milestone', `${milestone}%`);
            }
        });
    }, 1000));
}

// Initialize tracking
document.addEventListener('DOMContentLoaded', function() {
    trackPageView();
    initializeScrollTracking();
});

// ========================================
// SERVICE WORKER (for PWA features)
// ========================================
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('🔧 ServiceWorker registration successful');
            })
            .catch(function(error) {
                console.log('🔧 ServiceWorker registration failed');
            });
    });
}

// ========================================
// EXPORT FOR TESTING
// ========================================
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        CONFIG,
        scrollToTarget,
        validateField,
        showNotification
    };
}

// Console message
console.log(`
🍽️ Shawarma Hamamas Website
═══════════════════════════════════════
✨ Powered by modern web technologies
📱 Mobile-first responsive design
🎨 Inspired by authentic shawarma tradition
🚀 Built for optimal performance

Visit us at Parque Croata, Antofagasta!
📞 WhatsApp: +56 9 0000 0000
`);