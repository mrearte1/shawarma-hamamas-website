// Service Worker para Shawarma Hamamas
// PWA Support - Workbox-based service worker

const CACHE_NAME = 'shawarma-hamamas-v1.0.0';
const STATIC_CACHE = 'shawarma-static-v1.0.0';
const DYNAMIC_CACHE = 'shawarma-dynamic-v1.0.0';

// Assets to cache on install
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/styles/main.css',
    '/scripts/main.js',
    '/imgs/logo-shawarma-hamamas.svg',
    '/imgs/shawarma-hero.jpg',
    '/imgs/shawarma-pollo.jpg',
    '/imgs/shawarma-carne.jpg',
    '/imgs/shawarma-mixto.jpg',
    '/imgs/falafel.jpg',
    'https://fonts.googleapis.com/css2?family=Khand:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap'
];

// Network-first strategy for dynamic content
const DYNAMIC_ASSETS = [
    '/imgs/gallery-',
    'https://cdnjs.cloudflare.com/ajax/libs/lucide/0.263.1/umd/lucide.min.js'
];

// Install event - cache static assets
self.addEventListener('install', event => {
    console.log('🔧 Service Worker: Installing...');
    
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then(cache => {
                console.log('📦 Service Worker: Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                console.log('✅ Service Worker: Static assets cached');
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('❌ Service Worker: Failed to cache static assets', error);
            })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
    console.log('🔧 Service Worker: Activating...');
    
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames.map(cacheName => {
                        if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
                            console.log('🗑️ Service Worker: Deleting old cache', cacheName);
                            return caches.delete(cacheName);
                        }
                    })
                );
            })
            .then(() => {
                console.log('✅ Service Worker: Activated');
                return self.clients.claim();
            })
    );
});

// Fetch event - implement caching strategies
self.addEventListener('fetch', event => {
    const request = event.request;
    const url = new URL(request.url);
    
    // Skip non-GET requests
    if (request.method !== 'GET') {
        return;
    }
    
    // Skip external resources (except static assets we want to cache)
    if (url.origin !== location.origin && !DYNAMIC_ASSETS.some(asset => url.href.includes(asset))) {
        return;
    }
    
    // Strategy for different types of requests
    if (isStaticAsset(url)) {
        // Cache first for static assets
        event.respondWith(cacheFirst(request));
    } else if (isImage(url)) {
        // Cache first for images
        event.respondWith(cacheFirst(request));
    } else {
        // Network first for dynamic content
        event.respondWith(networkFirst(request));
    }
});

// Cache-first strategy
async function cacheFirst(request) {
    try {
        const cache = await caches.open(STATIC_CACHE);
        const cachedResponse = await cache.match(request);
        
        if (cachedResponse) {
            return cachedResponse;
        }
        
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.error('❌ Cache-first strategy failed:', error);
        return new Response('Network error', { status: 503 });
    }
}

// Network-first strategy
async function networkFirst(request) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            const cache = await caches.open(DYNAMIC_CACHE);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.log('🔍 Network failed, trying cache for:', request.url);
        
        const cache = await caches.open(DYNAMIC_CACHE);
        const cachedResponse = await cache.match(request);
        
        if (cachedResponse) {
            return cachedResponse;
        }
        
        // Return offline page or fallback
        return new Response(
            `
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Sin Conexión - Shawarma Hamamas</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        background: #FAF9F8;
                        color: #1C1917;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        margin: 0;
                        text-align: center;
                        padding: 20px;
                    }
                    .offline-container {
                        max-width: 400px;
                    }
                    .offline-icon {
                        width: 80px;
                        height: 80px;
                        background: #FF6700;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin: 0 auto 20px;
                    }
                    .offline-icon svg {
                        width: 40px;
                        height: 40px;
                        color: white;
                    }
                    h1 {
                        color: #2E7D32;
                        margin-bottom: 16px;
                    }
                    p {
                        color: #57534E;
                        margin-bottom: 20px;
                        line-height: 1.6;
                    }
                    .whatsapp-link {
                        display: inline-block;
                        background: #25D366;
                        color: white;
                        padding: 12px 24px;
                        text-decoration: none;
                        border-radius: 8px;
                        font-weight: 600;
                    }
                    .whatsapp-link:hover {
                        background: #20ba5a;
                    }
                </style>
            </head>
            <body>
                <div class="offline-container">
                    <div class="offline-icon">
                        <svg fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.64 7c-.45-.34-4.93-4-11.64-4-1.5 0-2.89.19-4.15.48L18.18 13.8 23.64 7zm-6.6 8.22L3.27 1.44 2 2.72l2.05 2.06C1.91 5.76.59 6.82.36 7l11.63 14.49.01.01.01-.01L17.73 14.27l2.55 2.55 1.27-1.27-5.51-5.51z"/>
                        </svg>
                    </div>
                    <h1>¡Parece que estás sin conexión!</h1>
                    <p>Pero no te preocupes, puedes seguir haciendo pedidos directamente por WhatsApp.</p>
                    <a href="https://wa.me/56900000000?text=Hola!%20Estoy%20sin%20internet%20pero%20quiero%20hacer%20un%20pedido%20de%20shawarma" class="whatsapp-link">
                        📱 Hacer pedido por WhatsApp
                    </a>
                </div>
            </body>
            </html>
            `,
            {
                headers: { 'Content-Type': 'text/html' },
                status: 503
            }
        );
    }
}

// Helper functions
function isStaticAsset(url) {
    const staticExtensions = ['.css', '.js', '.svg', '.woff2', '.woff'];
    return staticExtensions.some(ext => url.pathname.endsWith(ext)) || 
           STATIC_ASSETS.some(asset => url.href.includes(asset));
}

function isImage(url) {
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'];
    return imageExtensions.some(ext => url.pathname.endsWith(ext));
}

// Background sync for offline form submissions
self.addEventListener('sync', event => {
    if (event.tag === 'contact-form-submission') {
        event.waitUntil(
            // Process offline form submissions when back online
            console.log('🔄 Background sync: Processing offline contact form submissions')
        );
    }
});

// Push notifications (for future use)
self.addEventListener('push', event => {
    if (event.data) {
        const data = event.data.json();
        const options = {
            body: data.body,
            icon: '/imgs/logo-shawarma-hamamas.svg',
            badge: '/imgs/logo-shawarma-hamamas.svg',
            tag: 'shawarma-notification',
            actions: [
                {
                    action: 'whatsapp',
                    title: 'Hacer Pedido',
                    icon: '/imgs/logo-shawarma-hamamas.svg'
                },
                {
                    action: 'dismiss',
                    title: 'Cerrar',
                    icon: '/imgs/logo-shawarma-hamamas.svg'
                }
            ]
        };
        
        event.waitUntil(
            self.registration.showNotification(data.title, options)
        );
    }
});

// Notification click handling
self.addEventListener('notificationclick', event => {
    event.notification.close();
    
    if (event.action === 'whatsapp') {
        event.waitUntil(
            clients.openWindow('https://wa.me/56900000000?text=Hola!%20Vengo%20de%20una%20notificación%20y%20quiero%20hacer%20un%20pedido')
        );
    } else if (event.action === 'dismiss') {
        // Just close the notification
    } else {
        // Default action - open the website
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

console.log('🍽️ Shawarma Hamamas Service Worker loaded successfully!');