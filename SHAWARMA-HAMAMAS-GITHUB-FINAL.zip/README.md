# 🍽️ Shawarma Hamamas - Sitio Web Oficial

> **Food truck auténtico en Antofagasta, Chile**  
> *6 años sirviendo los mejores shawarmas en Parque Croata*

[![GitHub](https://img.shields.io/badge/GitHub-Repository-blue?style=flat&logo=github)](https://github.com/tu-usuario/shawarma-hamamas)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![Responsive](https://img.shields.io/badge/Responsive-Mobile--First-blue.svg)](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)

---

## 🌟 Acerca de Nosotros

**Shawarma Hamamas** es un food truck establecido con **6 años de experiencia** que ofrece shawarmas auténticos en el corazón de **Parque Croata, Antofagasta, Chile**. 

Nos especializamos en preparar shawarmas tradicionales con ingredientes frescos y especias árabes originales, manteniendo la autenticidad de la receta tradicional.

### 🥙 Nuestros Productos

| Producto | Precio | Descripción |
|----------|--------|-------------|
| **Shawarma de Pollo** | $7.500 | Pechuga marinada con especias árabes, vegetales frescos, hummus y salsa de ajo |
| **Shawarma de Carne** | $8.000 | Carne de res premium cortada al momento, cebolla caramelizada, lechuga fresca y tomates |
| **Shawarma Mixto** | $8.500 | La combinación perfecta de pollo y carne, nuestro plato estrella |
| **Shawarma Vegetariano** | $6.500 | Falafel crujiente con garbanzos frescos, hierbas aromáticas y hummus |
| **Papas Fritas** | $2.500 | Crujientes por fuera, suaves por dentro |

#### 🥤 Bebidas
- **Gaseosas**: Coca-Cola, Sprite, Fanta - $1.200
- **Agua**: Agua mineral natural - $800  
- **Jugo**: Jugo de frutas naturales - $1.500

#### 🍽️ Combos Especiales
- **Combo Individual**: Shawarma + Bebida - $9.500
- **Combo Pareja**: 2 Shawarmas + 2 Bebidas - $15.000
- **Combo Familia**: 3 Shawarmas + 3 Bebidas + 1 Hummus - $21.500

### ⏰ Horarios de Atención

- **Martes a Viernes**: 19:00 - 01:00
- **Sábado y Domingo**: 18:00 - 02:00
- **Lunes**: Cerrado

### 📍 Ubicación

**Parque Croata, Antofagasta, Chile**

---

## 🚀 Características del Sitio Web

### ✨ Diseño y Experiencia
- 📱 **Diseño Responsivo**: Optimizado para móviles, tablets y desktop
- 🎨 **Identidad Visual**: Colores basados en el food truck real (verde lima vibrante)
- 📷 **Imágenes Reales**: Foto auténtica del food truck
- ⚡ **Rendimiento Optimizado**: Carga rápida y eficiente
- 🔒 **SSL Seguro**: Conexión HTTPS automática

### 🛒 Funcionalidades de Pedido
- 📱 **Integración WhatsApp**: Botones directos para cada producto
- 💬 **Mensajes Pre-configurados**: Textos personalizados por producto
- 🍽️ **Menú Completo**: Todos los productos disponibles con precios actualizados
- 🎁 **Combos Especiales**: Ofertas para individuos, parejas y familias

### 📊 Marketing Digital
- 🎯 **SEO Optimizado**: Meta tags y optimizaciones para Antofagasta
- 📸 **Galería Visual**: Showcase de productos y ambiente del food truck
- 📍 **Información de Ubicación**: Horarios, direcciones y contacto
- 📝 **Formulario de Contacto**: Comunicación directa con clientes
- 📲 **PWA Ready**: Instalable como aplicación móvil

---

## 🛠️ Tecnologías Utilizadas

- **HTML5**: Estructura semántica y accesible
- **CSS3**: Diseño moderno con CSS Grid y Flexbox
- **JavaScript (ES6+)**: Funcionalidad interactiva y optimizada
- **Lucide Icons**: Iconografía moderna y vectorial
- **Google Fonts**: Tipografías Khand (títulos) e Inter (cuerpo)
- **CSS Variables**: Sistema de diseño consistente
- **Progressive Web App**: Funcionalidades offline

---

## 📁 Estructura del Proyecto

```
/
├── index.html              # Página principal
├── styles/
│   └── main.css            # Estilos principales (1,419 líneas)
├── scripts/
│   └── main.js             # JavaScript funcional (675 líneas)
├── imgs/                   # Imágenes del sitio
│   ├── logo-shawarma-hamamas.svg
│   ├── food-truck-real.png # Imagen real del food truck
│   ├── gallery-*.jpg       # Galería de productos
│   └── *.jpg              # Productos individuales
├── manifest.json           # PWA manifest
├── sw.js                   # Service Worker
├── favicon.ico             # Icono del sitio
├── netlify.toml            # Configuración Netlify
├── vercel.json             # Configuración Vercel
├── .htaccess               # Configuración Apache
└── README.md               # Este archivo
```

---

## 🎯 Instalación y Uso

### 📦 Instalación Local

```bash
# Clonar el repositorio
git clone https://github.com/tu-usuario/shawarma-hamamas.git

# Entrar al directorio
cd shawarma-hamamas

# Abrir en navegador
open index.html
```

### 🌐 Deploy en GitHub Pages

1. **Fork este repositorio**
2. **Ir a Settings > Pages**
3. **Seleccionar Source: Deploy from a branch**
4. **Branch: main / Root**
5. **Tu sitio estará disponible en**: `https://tu-usuario.github.io/shawarma-hamamas`

### ☁️ Deploy Alternativo

#### 🌟 Netlify (Recomendado)
```bash
1. Ir a netlify.com
2. Arrastrar carpeta del proyecto
3. ¡URL instantánea!
```

#### ⚡ Vercel
```bash
1. Ir a vercel.com
2. Conectar con GitHub
3. Deploy automático
```

---

## 🎨 Paleta de Colores

```css
:root {
  --primary-orange: #FF6700;    /* Naranja vibrante */
  --primary-green:  #9ACD32;    /* Verde lima del food truck */
  --neutral-dark:   #1C1917;    /* Texto principal */
  --neutral-medium: #57534E;    /* Texto secundario */
  --neutral-light:  #F7F6F5;    /* Fondo claro */
}
```

---

## 📱 Características Técnicas

### ✅ Optimizaciones Incluidas:
- ⚡ **Compresión GZIP**: Páginas más rápidas
- 🗂️ **Cache de archivos**: Mejor rendimiento
- 🔒 **SSL forzado**: HTTPS obligatorio
- 🔄 **Redirecciones SEO**: Optimizado para Google
- 🛡️ **Headers de seguridad**: Protección básica
- 📱 **Mobile-first**: Diseño responsive

### 🎯 Métricas de Rendimiento:
- **Carga inicial**: < 2 segundos
- **Lighthouse Score**: 95+ (Performance, Accessibility, SEO)
- **Mobile-friendly**: ✅ Optimizado
- **PWA**: ✅ Instalable

---

## 📊 Analytics y Métricas

### 📈 Analytics Sugeridos:
- **Google Analytics 4**: Seguimiento de tráfico
- **Google Search Console**: SEO y rendimiento
- **Netlify Analytics**: Métricas de hosting (si usa Netlify)

### 🔍 Palabras Clave SEO:
- shawarma antofagasta
- food truck antofagasta
- shawarma parque croata
- comida arabe antofagasta
- shawarma hamamas

---

## 📞 Contacto

- **Dirección**: Parque Croata, Antofagasta, Chile
- **Horarios**: Mar-Vie 19:00-01:00, Sáb-Dom 18:00-02:00
- **WhatsApp**: +56 9 XXXX XXXX
- **Email**: shawarmahamamas@email.com

### 📱 Redes Sociales
- **Instagram**: [@shawarmahamamas](https://instagram.com/shawarmahamamas)
- **Facebook**: [Shawarma Hamamas](https://facebook.com/shawarmahamamas)
- **TikTok**: [@shawarmahamamas](https://tiktok.com/@shawarmahamamas)

---

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Si deseas mejorar el sitio web:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

---

## 👨‍💻 Desarrollado por

**MiniMax Agent** - Noviembre 2025

*Sitio web optimizado para Shawarma Hamamas - Antofagasta, Chile*

---

## 🙏 Agradecimientos

- Food truck original por la foto auténtica
- Comunidad de desarrolladores open source
- Bibliotecas y recursos utilizados
- Clientes de Shawarma Hamamas por su apoyo

---

## 📞 Soporte

Si tienes preguntas o necesitas ayuda:

- 📧 **Email**: contacto@shawarmahamamas.cl
- 📱 **WhatsApp**: +56 9 XXXX XXXX
- 🌐 **Sitio Web**: [shawarmahamamas.cl](https://shawarmahamamas.cl)

---

⭐ **Si este proyecto te sirvió, ¡déjanos una estrella en GitHub!** ⭐

![GitHub stars](https://img.shields.io/github/stars/tu-usuario/shawarma-hamamas?style=social)
![GitHub forks](https://img.shields.io/github/forks/tu-usuario/shawarma-hamamas?style=social)

## 📁 Estructura del Proyecto

```
/
├── index.html              # Página principal
├── styles/
│   └── main.css            # Estilos principales
├── scripts/
│   └── main.js             # JavaScript principal
├── imgs/                   # Imágenes optimizadas
│   ├── logo-shawarma-hamamas.svg
│   ├── shawarma-hero.jpg
│   ├── shawarma-pollo.jpg
│   ├── shawarma-carne.jpg
│   ├── shawarma-mixto.jpg
│   ├── falafel.jpg
│   └── gallery-*.jpg
└── README.md               # Este archivo
```

## 🎨 Diseño y Branding

### Paleta de Colores
- **Naranja Principal**: `#FF6700` - Llamadas a la acción y elementos destacados
- **Verde Principal**: `#2E7D32` - Branding y elementos secundarios
- **Neutros**: Escala de grises para texto y fondos

### Tipografía
- **Títulos**: Khand (Google Fonts) - Bold y moderno
- **Texto**: Inter (Google Fonts) - Legible y versátil

### Estilo Visual
- Diseño inspirado en video de YouTube: https://youtu.be/LcDBXC_sfB0
- Estética de food truck moderna y limpia
- Imágenes de alta calidad que muestran autenticidad
- Elementos visuales que evocan la cultura árabe

## 📱 Funcionalidades

### Menú Principal
- **Shawarma de Pollo**: $7.500
- **Shawarma de Carne**: $8.000
- **Shawarma Mixto**: $8.500
- **Shawarma Vegetariano (Falafel)**: $6.500

### Combos Especiales
- **Combo Individual**: $9.500 (Shawarma + Bebida)
- **Combo Pareja**: $15.000 (2 Shawarmas + 2 Bebidas)
- **Combo Familia**: $21.500 (3 Shawarmas + 3 Bebidas + Hummus)

### Información de Contacto
- **WhatsApp**: +56 9 0000 0000
- **Ubicación**: Parque Croata, Antofagasta
- **Horarios**: 
  - Martes a Viernes: 19:00 - 01:00
  - Sábado a Domingo: 18:00 - 02:00
  - Lunes: Cerrado

## 🚀 Instalación y Uso

### Requisitos
- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- Servidor web local (para desarrollo)

### Instalación Local
1. Descargar todos los archivos del proyecto
2. Abrir `index.html` en un navegador web
3. Para desarrollo, usar un servidor local como:
   ```bash
   # Python 3
   python -m http.server 8000
   
   # Node.js
   npx serve .
   
   # PHP
   php -S localhost:8000
   ```

### Configuración Personalizada

#### Actualizar Información de Contacto
Editar el archivo `index.html` y buscar:
- Número de WhatsApp en línea 15 y línea 428
- Información de ubicación y horarios
- Enlaces a redes sociales

#### Cambiar Imágenes
Reemplazar archivos en la carpeta `imgs/` manteniendo los mismos nombres:
- `shawarma-hero.jpg` - Imagen principal del hero
- `shawarma-pollo.jpg` - Producto de pollo
- `shawarma-carne.jpg` - Producto de carne
- `shawarma-mixto.jpg` - Producto mixto
- `falafel.jpg` - Producto vegetariano
- `gallery-*.jpg` - Imágenes de la galería

#### Personalizar Colores
Editar las variables CSS en `styles/main.css`:
```css
:root {
    --primary-orange-500: #FF6700;
    --primary-green-500: #2E7D32;
    /* ... más variables */
}
```

## 📊 SEO y Rendimiento

### Optimizaciones Incluidas
- **Meta tags** optimizados para búsquedas locales
- **Open Graph** para redes sociales
- **Structured Data** para restaurantes
- **Imágenes optimizadas** con lazy loading
- **CSS y JS minificados** para carga rápida
- **Responsive design** para todos los dispositivos

### Palabras Clave Objetivo
- "shawarma Antofagasta"
- "comida árabe Antofagasta"
- "food truck Parque Croata"
- "delivery shawarma Antofagasta"
- "kebab Antofagasta"

## 🔧 Personalización Avanzada

### Google Analytics
Para integrar Google Analytics:
1. Agregar el código de tracking en `<head>`
2. Actualizar el archivo `scripts/main.js` con eventos de tracking

### Integración con Redes Sociales
- Actualizar enlaces en el footer
- Configurar Pixel de Facebook para tracking
- Integrar API de Instagram para contenido automático

### Sistema de Pedidos Online
Para implementar pedidos online:
1. Integrar API de WhatsApp Business
2. Conectar con sistema de pagos (Transbank, PayPal)
3. Implementar carrito de compras

## 📞 Soporte y Mantenimiento

### Actualizaciones Recomendadas
- **Mensual**: Actualizar imágenes de productos
- **Trimestral**: Revisar y actualizar horarios/eventos
- **Semestral**: Análisis de rendimiento y mejoras

### Métricas a Monitorear
- Tiempo de carga de página
- Tasa de conversión de WhatsApp
- Posicionamiento en Google Maps
- Engagement en redes sociales

## 🎥 Inspiración Visual

El diseño de este sitio web está inspirado en el video de YouTube: [Shawarma Harmamas](https://youtu.be/LcDBXC_sfB0)

Elementos inspirados del video:
- Paleta de colores verde y naranja
- Estética de food truck moderna
- Preparación en plancha (no asador vertical)
- Ambiente festivo y familiar
- Enfoque en frescura y calidad

## 📜 Licencia

Este proyecto fue desarrollado para Shawarma Hamamas. Todos los derechos reservados.

---

**🍽️ ¡Disfruta de nuestros shawarmas auténticos en Parque Croata, Antofagasta!**

Para pedidos y consultas: [WhatsApp +56 9 0000 0000](https://wa.me/56900000000)